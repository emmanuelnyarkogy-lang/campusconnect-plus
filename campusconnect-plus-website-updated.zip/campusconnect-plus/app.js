// Add the official team WhatsApp number here when it is confirmed.
// Use international digits only. Ghana example: 233XXXXXXXXX (omit the first 0).
const CONFIG = { teamWhatsApp: "233206983773" };

const categories = [
  {name:"Food & refreshments",icon:"🍲",desc:"Meals, snacks, drinks and campus food vendors."},
  {name:"Printing & photocopying",icon:"🖨️",desc:"Printing, photocopying, scanning and document services."},
  {name:"Stationery & study supplies",icon:"📚",desc:"Books, pens, notebooks and other academic essentials."},
  {name:"Errands & delivery",icon:"🛵",desc:"Campus errands, pickups and delivery assistance."},
  {name:"Laundry & personal care",icon:"🧺",desc:"Laundry and everyday personal services."},
  {name:"Other campus services",icon:"＋",desc:"Tell us what you need and we'll help direct your enquiry."}
];

const grid=document.getElementById("serviceGrid");
const select=document.getElementById("category");
categories.forEach((item,i)=>{
  const card=document.createElement("article");card.className="service-card";
  card.innerHTML=`<div class="service-icon">${item.icon}</div><h3>${item.name}</h3><p>${item.desc}</p><a href="#order" data-category="${i}">Request this →</a>`;
  grid.appendChild(card);
  const option=document.createElement("option");option.value=item.name;option.textContent=item.name;select.appendChild(option);
});
document.querySelectorAll("[data-category]").forEach(link=>link.addEventListener("click",()=>select.value=categories[Number(link.dataset.category)].name));

document.getElementById("orderForm").addEventListener("submit",e=>{
  e.preventDefault();
  const data=new FormData(e.currentTarget);
  const message=[
    "Hello CampusConnect Plus, I would like to make an enquiry/order.",
    "",
    `Name: ${data.get("name")}`,
    `WhatsApp: ${data.get("phone")}`,
    `Campus/location: ${data.get("campus")}`,
    `Category: ${data.get("category")}`,
    `Order details: ${data.get("description")}`
  ].join("\n");
  const number=CONFIG.teamWhatsApp.replace(/\D/g,"");
  const status=document.getElementById("formMessage");
  if(!number){status.textContent="The CampusConnect Plus WhatsApp number will be connected once you provide it. The form is ready; no message has been sent.";return;}
  status.textContent="Opening WhatsApp. Review your message and press Send when ready.";
  window.open(`https://wa.me/${number}?text=${encodeURIComponent(message)}`,"_blank","noopener");
});
document.getElementById("menuToggle").addEventListener("click",()=>document.getElementById("nav").classList.toggle("open"));
document.querySelectorAll("#nav a").forEach(a=>a.addEventListener("click",()=>document.getElementById("nav").classList.remove("open")));
document.getElementById("year").textContent=new Date().getFullYear();
if("serviceWorker" in navigator && location.protocol.startsWith("http"))window.addEventListener("load",()=>navigator.serviceWorker.register("./sw.js").catch(console.error));
